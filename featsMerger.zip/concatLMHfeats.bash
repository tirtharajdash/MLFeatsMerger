#!/bin/bash

#Usage: It takes two files and merge them horizontally based on matching first column. Used for feature concatenation.

prefixdir="/home/dash/Research/HideSeek_QSAR/Data100"

for i in `cat $prefixdir/DS100`
do
	echo $i
	
	for j in 1 2 3 4 5 6 7 8 9 10
	do
		#remove all lines with @, blank lines and then remove the last column to form a cancatenate-ble files
		cat output/$i/$j/train1.arff | sed '/^@/ d' | sed '/^$/ d' | gawk 'NF{NF-=1};1' | sed 's/,$//' > output/$i/$j/train1.txt
		cat output/$i/$j/train2.arff | sed '/^@/ d' | sed '/^$/ d' | gawk 'NF{NF-=1};1' | sed 's/,$//' > output/$i/$j/train2.txt
		cat output/$i/$j/train3.arff | sed '/^@/ d' | sed '/^$/ d' | gawk 'NF{NF-=1};1' | sed 's/,$//' > output/$i/$j/train3.txt
		cat output/$i/$j/test1.arff | sed '/^@/ d' | sed '/^$/ d' | gawk 'NF{NF-=1};1' | sed 's/,$//' > output/$i/$j/test1.txt
		cat output/$i/$j/test2.arff | sed '/^@/ d' | sed '/^$/ d' | gawk 'NF{NF-=1};1' | sed 's/,$//' > output/$i/$j/test2.txt
		cat output/$i/$j/test3.arff | sed '/^@/ d' | sed '/^$/ d' | gawk 'NF{NF-=1};1' | sed 's/,$//' > output/$i/$j/test3.txt

		#concatenate the files 1 and 2 to form 12 and follow the same for generating 123
		gawk -F, 'NR==FNR{a[$1]=substr($0,length($1)+2);next} ($1 in a){print $0","a[$1]}' output/$i/$j/train2.txt output/$i/$j/train1.txt > /tmp/train12.txt
		gawk -F, 'NR==FNR{a[$1]=substr($0,length($1)+2);next} ($1 in a){print $0","a[$1]}' output/$i/$j/train3.txt /tmp/train12.txt > /tmp/train123.txt
		
		gawk -F, 'NR==FNR{a[$1]=substr($0,length($1)+2);next} ($1 in a){print $0","a[$1]}' output/$i/$j/test2.txt output/$i/$j/test1.txt > /tmp/test12.txt
		gawk -F, 'NR==FNR{a[$1]=substr($0,length($1)+2);next} ($1 in a){print $0","a[$1]}' output/$i/$j/test3.txt /tmp/test12.txt > /tmp/test123.txt

		#now generate the activity file in the format molId,activity
		cat $prefixdir/$i/$j/train.pl | grep "activity" | sed "s/activity('//" | sed "s/'//" | sed "s/).//" > output/$i/$j/trainact.txt
		cat $prefixdir/$i/$j/test.pl | grep "activity" | sed "s/activity('//" | sed "s/'//" | sed "s/).//" > output/$i/$j/testact.txt

		#merge the activity with other features as the last column (perfect for ML design)
		gawk -F, 'NR==FNR{a[$1]=substr($0,length($1)+2);next} ($1 in a){print $0","a[$1]}' output/$i/$j/trainact.txt /tmp/train123.txt > output/$i/$j/train.txt
		gawk -F, 'NR==FNR{a[$1]=substr($0,length($1)+2);next} ($1 in a){print $0","a[$1]}' output/$i/$j/testact.txt /tmp/test123.txt > output/$i/$j/test.txt

		#clear the tmp directory by deleting the tmp files generated during the process
		/bin/rm /tmp/train*.txt
		/bin/rm /tmp/test*.txt
	done
done
